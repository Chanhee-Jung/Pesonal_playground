#include <unistd.h>
#include <cstddef>
#include <set>
#include <string>
#include <vector>
#include <fstream>
#include <sstream>
#include <iostream>
#include "process.h"
#include "processor.h"
#include "system.h"

using std::set;
using std::size_t;
using std::string;
using std::vector;

// TODO: Return the system's CPU
Processor& System::Cpu() { return cpu_; }

// TODO: Return a container composed of the system's processes
vector<Process>& System::Processes() { return processes_; }

// TODO: Return the system's kernel identifier (string)
std::string System::Kernel() { 

    std:: ifstream readVer;
    readVer.open("/proc/version");
    std::string line;
    std::string Kernelstr;

    if(readVer.is_open())
    {
             
       while(getline(readVer,line))
        {
            if(line.find("version")==std::string::npos)
            {
            }
            else
            {
               int cnt = line.find("version");
               line=line.substr(cnt);
               int fnd = line.find('(');
                Kernelstr=line.substr(0,fnd);
            }
            
        }
    }
    return Kernelstr;

}
// TODO: Return the system's memory utilization
float System::MemoryUtilization() {
    
    std:: ifstream readVer;
    readVer.open("/proc/meminfo");
    std::string line;   
    float totalmem;
    float memfree;
    float fnum;
    if(readVer.is_open())
    {
             
       while(getline(readVer,line))
        {
            if(line.find("MemTotal")==std::string::npos)
            {
                
            }
            else
            {

               int cnt = line.find(":");
               line=line.substr(cnt+1);
               std:: istringstream sline(line);
               while (sline >>fnum)
               {
                    totalmem=fnum;
               }
            }
           if(line.find("MemFree")==std::string::npos)
            {
                
            }
            else
            {

               int cnt = line.find(":");
               line=line.substr(cnt+1);
               std:: istringstream sline(line);
               while (sline >>fnum)
               {
                    memfree=fnum;
               }
            }
        }

    }   

     return ((totalmem-memfree)/totalmem);
}

// TODO: Return the operating system name
std::string System::OperatingSystem() { 


    std:: ifstream readfile;
    readfile.open("/etc/os-release");
    std::string line;
    std::string Name;

    if(readfile.is_open())
    {
             
       while(getline(readfile,line))
        {
            if(line.find("PRETTY_NAME")==std::string::npos)
            {
            }
            else
            {
               int cnt = line.find('"');
               line=line.substr(cnt+1);
               int fnd = line.find('"');
                Name = line.substr(0,fnd);
            }
            
        }
    
    }
 
    return Name;
 }




// TODO: Return the number of processes actively running on the system
int System::RunningProcesses() { 
    
    std:: ifstream readfile;
    readfile.open("/proc/stat");
    std::string line;
    std::string s;
    int inum;
    int runningproc;
     
    if(readfile.is_open())
    {
            
       while(getline(readfile,line))
        {
            if(line.find("running")==std::string::npos)
            {
            }
            else
            {
             std:: istringstream sline(line);
            
               while (sline >>s >>inum)
               {

                    runningproc=inum;
               }
               
            }
            
        }
   
    }
    return runningproc; 
}
// TODO: Return the total number of processes on the system
int System::TotalProcesses() { 
    

    std:: ifstream readfile;
    readfile.open("/proc/stat");
    std::string line;
    std::string s;
    int inum;
    int Totalprocesses;
     
    if(readfile.is_open())
    {
            
       while(getline(readfile,line))
        {
            if(line.find("processes")==std::string::npos)
            {
            }
            else
            {
             std:: istringstream sline(line);
            
               while (sline >>s >>inum)
               {
                    Totalprocesses=inum;
               }
               
            }
            
        }
   
    }
    return Totalprocesses; 
}

// TODO: Return the number of seconds since the system started running
long System::UpTime() { 
    
    std:: ifstream readfile;
    readfile.open("/proc/uptime");
    std::string line;

    double d1;
    double d2;
    long sectime;
  
     
    if(readfile.is_open())
    {
            
       while(getline(readfile,line))
        {

             std:: istringstream sline(line);
            
               while (sline >>d1 >>d2)
               {
                sectime=(long)d2;
               }
       
        }
   
    }
    return sectime;

}
    
