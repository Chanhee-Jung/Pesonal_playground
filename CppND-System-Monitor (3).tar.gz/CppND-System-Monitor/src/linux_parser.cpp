#include <dirent.h>
#include <unistd.h>
#include <string>
#include <vector>
#include <numeric>
#include "processor.h"
#include "linux_parser.h"
#include "system.h"
#include <iostream>
using std::stof;
using std::string;
using std::to_string;
using std::vector;

// DONE: An example of how to read data from the filesystem
string LinuxParser::OperatingSystem() {
  string line;
  string key;
  string value;
  std::ifstream filestream(kOSPath);
  if (filestream.is_open()) {
    while (std::getline(filestream, line)) {
      std::replace(line.begin(), line.end(), ' ', '_');
      std::replace(line.begin(), line.end(), '=', ' ');
      std::replace(line.begin(), line.end(), '"', ' ');
      std::istringstream linestream(line);
      while (linestream >> key >> value) {
        if (key == "PRETTY_NAME") {
          std::replace(value.begin(), value.end(), '_', ' ');
          return value;
        }
      }
    }
  }
  return value;
}

// DONE: An example of how to read data from the filesystem
string LinuxParser::Kernel() {
  string os, kernel;
  string line;
  std::ifstream stream(kProcDirectory + kVersionFilename);
  if (stream.is_open()) {
    std::getline(stream, line);
    std::istringstream linestream(line);
    linestream >> os >> kernel;
  }
  return kernel;
}

// BONUS: Update this to use std::filesystem
vector<int> LinuxParser::Pids() {
  vector<int> pids;
  DIR* directory = opendir(kProcDirectory.c_str());
  struct dirent* file;
  while ((file = readdir(directory)) != nullptr) {
    // Is this a directory?
    if (file->d_type == DT_DIR) {
      // Is every character of the name a digit?
      string filename(file->d_name);
      if (std::all_of(filename.begin(), filename.end(), isdigit)) {
        int pid = stoi(filename);
      
          pids.push_back(pid);
   
      }
    }
  }
  closedir(directory);

  return pids;
}

// Done: Read and return the system memory utilization
float LinuxParser::MemoryUtilization() {
   std:: ifstream readVer;
    readVer.open("/proc/meminfo");
    std::string line;   
    float totalmem;
    float memfree;
    float fnum;
    if(readVer.is_open())
    {    
       while(getline(readVer,line))
        {
            if(line.find("MemTotal")==std::string::npos)
            { 
            }
            else
            {
               int cnt = line.find(":");
               line=line.substr(cnt+1);
               std:: istringstream sline(line);
               while (sline >>fnum)
               {
                    totalmem=fnum;
               }
            }
           if(line.find("MemFree")==std::string::npos)
            {
                
            }
            else
            {

               int cnt = line.find(":");
               line=line.substr(cnt+1);
               std:: istringstream sline(line);
               while (sline >>fnum)
               {
                    memfree=fnum;
               }
            }
        }
    }   
     return ((totalmem-memfree)/totalmem);
  }

// Done: Read and return the system uptime
long LinuxParser::UpTime() {    
  std:: ifstream readfile;
    readfile.open("/proc/uptime");
    std::string line;
    long d1;
    long d2;
    long sectime;
    if(readfile.is_open())
    {            
       while(getline(readfile,line))
        {

             std:: istringstream sline(line);
            
               while (sline >>d1>>d2)
               {
                sectime=d1;
               }
    
        }
    }

    return sectime;
 }

// DONE: Read and return the number of jiffies for the system
long LinuxParser::Jiffies() { 
 return LinuxParser::UpTime()*sysconf(_SC_CLK_TCK);
  }

// DONE: Read and return the number of active jiffies for a PID
// REMOVE: [[maybe_unused]] once you define the function
long LinuxParser::ActiveJiffies(int pid) { 
    std::string line;
    std::string str;
   long SumActivejiffies;
    std::string filename=to_string(pid);
    int i=0;
    std::ifstream stream(kProcDirectory+filename + kStatFilename);
     if (stream.is_open()) {
    std::getline(stream, line);
    std::istringstream linestream(line);
    while( linestream >> str)
    {
      if (i==13 || i==14 || i==15 || i==16)
      {
       
       if(str=="")
       {
         str="0";
 
       }
      SumActivejiffies=SumActivejiffies+stol(str);
      if (i==16)
      {
        break;
      }
       
      }
      i++;
    }
  }
  return SumActivejiffies; 
  }

// DONE: Read and return the number of active jiffies for the system
long LinuxParser::ActiveJiffies()
 {  
   std:: vector<long> ActvieJiffy = LinuxParser :: CpuUtilization();
   long SumActiveJiffy =std::accumulate(ActvieJiffy.begin(),ActvieJiffy.end(),0);


   return SumActiveJiffy; }

// DONE: Read and return the number of idle jiffies for the system
long LinuxParser::IdleJiffies() {
   std:: vector<long> ActvieJiffy = LinuxParser :: CpuUtilization();
  
   return  ActvieJiffy[3]+ActvieJiffy[4]; }

// DONE: Read and return CPU utilization
vector<long> LinuxParser::CpuUtilization() { 
      std::vector<long> Data (10,0);
    int i=0;
    std::string str;
    std::string line;
    long l;
    std::ifstream stream ("/proc/stat");
    if (stream.is_open())
    {
  
      while(std::getline(stream, line))
      {
            std::istringstream linestream(line);
        while (linestream >> str && str =="cpu"){
           //std::cout <<str << "\n";
        //   std::cout <<linestream << "\n";
          while (linestream >> l)
          {
            Data[i]=l;
             i=i+1;
     
          }
         break;
        }
      }
    }  
     return Data;
 }

// Done: Read and return the total number of processes
int LinuxParser::TotalProcesses() {
    std:: ifstream readfile;
    readfile.open("/proc/stat");
    std::string line;
    std::string s;
    int inum;
    int Totalprocesses;
     
    if(readfile.is_open())
    {       
       while(getline(readfile,line))
        {
            if(line.find("processes")==std::string::npos)
            {
            }
            else
            {
             std:: istringstream sline(line);
               while (sline >>s >>inum)
               {
                    Totalprocesses=inum;
               } 
            }
            
        }
   
    }


    return Totalprocesses; 
 }

// Done: Read and return the number of running processes
int LinuxParser::RunningProcesses() {     
    std:: ifstream readfile;
    readfile.open("/proc/stat");
    std::string line;
    std::string s;
    int inum;
    int runningproc;
    if(readfile.is_open())
    {     
       while(getline(readfile,line))
        {
            if(line.find("running")==std::string::npos)
            {
            }
            else
            {
             std:: istringstream sline(line);
               while (sline >>s >>inum)
               {

                    runningproc=inum;
               }
            } 
        }

    }


    return runningproc;  
}

// DONE: Read and return the command associated with a process

string LinuxParser::Command(int pid) { 
      std::string line;
    std::string Command;
    std::string filename=to_string(pid);
    std::ifstream stream(kProcDirectory+filename + kCmdlineFilename);
     if (stream.is_open()) {
    std::getline(stream, line);
     }
    return line;
 }

// DONE: Read and return the memory used by a process

string LinuxParser::Ram(int pid) { 
    std::string filename=to_string(pid);
   std::ifstream stream(kProcDirectory+filename + kStatusFilename);
   std::string str;
   std::string RamName;
   std::string KB;
   std::string line;
    while (std::getline(stream, line)) {
      
     if(line.find("VmSize:")==std::string::npos)
    {  
    } 
     else
     {
      std::istringstream linestream(line);
                               
      while (linestream >> RamName >>  str >>KB && KB=="kB") {
           str =str;
           break;
           }
      }
    }

    return str;
 }

// DONE: Read and return the user ID associated with a process

string LinuxParser::Uid(int pid) {
    std::string filename=to_string(pid);
   std::ifstream stream(kProcDirectory+filename + kStatusFilename);
   std::string str;
   std::string UID;
   std::string line;
    while (std::getline(stream, line)) {
      
     if(line.find("Uid:")==std::string::npos)
    {  
    } 
     else
     {
      std::istringstream linestream(line);
                               
      while (linestream >> UID >>  str && UID =="Uid") {
           str =str;
           break;
           }
      }
    }

    return str;
 }

// DONE: Read and return the user associated with a process

string LinuxParser::User(int pid) {
  std::string UID= LinuxParser::Uid(pid);
  std::ifstream stream(kPasswordPath);
  string UserName;
  string line;
  string str;
  string x;
  while (std::getline(stream,line))
  {
    std::replace(line.begin(), line.end(), ':', ' ');
    std::istringstream linestream(line);
    while (linestream >> UserName >> x >> str && x=="x" && UID==str)
    {
       UserName=UserName;
    }
  }
   return UserName; }

// TODO: Read and return the uptime of a process
// REMOVE: [[maybe_unused]] once you define the function
long LinuxParser::UpTime(int pid) {
      std::string line;
    std::string str;
    std::string Up_times=0;
    std::string filename=to_string(pid);
   
    int i=0;
    std::ifstream stream(kProcDirectory+filename+kStatFilename);
     if (stream.is_open()) {
    std::getline(stream, line);
    std::istringstream linestream(line);
    while( linestream >> str)
    {
      if (i==21)
      {
      
         Up_times=(str);
       break;;
      }
      i=i+1;
    }
  }

if(Up_times=="")
{
  Up_times="0";
}
return stol(Up_times);//Up_times;
}


