#include "processor.h"
#include <string>
#include <vector>
#include <fstream>
#include <sstream>
#include <iostream>
#include "linux_parser.h"

// Done: Return the aggregate CPU utilization
float Processor::Utilization() {
   static std::vector<long> PreData(10,0);
   std::vector<long> Data=LinuxParser::CpuUtilization();
  
  long Prev_Idle=PreData[3]+PreData[4];
  long Idle=Data[3]+Data[4];
  long PreNonIdle=PreData[0]+PreData[1]+PreData[2]+PreData[5]+PreData[6]+PreData[7];
  long NonIdle=Data[0]+Data[1]+Data[2]+Data[5]+Data[6]+Data[7];
  long PreTotal=Prev_Idle+PreNonIdle;
  long Total=Idle+NonIdle;
  long totald=Total-PreTotal;
  long idled =Idle-Prev_Idle;
  std::copy(Data.begin(),Data.end(),PreData.begin());

  return (float)(totald-idled)/totald;

 }

