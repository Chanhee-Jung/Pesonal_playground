#include <unistd.h>
#include <cctype>
#include <sstream>
#include <string>
#include <vector>
#include "linux_parser.h"
#include "process.h"
#include <unistd.h>

using std::string;
using std::to_string;
using std::vector;
using std::stof;

// TODO: Return this process's ID
Process::Process(int pid)
{
    
      Process::_pid=pid;

  };
int Process::Pid() { 

    
    return _pid; }

// TODO: Return this process's CPU utilization
float Process::CpuUtilization() const {
  float uptime= (float)LinuxParser::UpTime();
   float startime=(float) LinuxParser::UpTime(_pid);
   float totaltime=(float)LinuxParser::ActiveJiffies(_pid)/sysconf(_SC_CLK_TCK);
   float seconds=(uptime-(startime/sysconf(_SC_CLK_TCK)));
   float cpuutilization_v=(float)(totaltime/seconds);

  // if ( filename=="9" || filename=="30")
  // {
  //  std::cout<< "\n" << totaltime<< " " << sysconf(_SC_CLK_TCK)<< "\n";
  //  std::cout<<seconds<<" "<< cpuutil<<"\n";
  // }
    return  cpuutilization_v;
}
// DONE: Return the command that generated this process
string Process::Command() { 
   return LinuxParser::Command(_pid);
}

// DONE: Return this process's memory utilization
string Process::Ram() { 
     string str =LinuxParser::Ram(_pid);
     if(str=="")
     {
       str="0";
     }
    long l = std::stol(str)/1000;

    return  to_string(l);
}
// TODO: Return the user (name) that generated this process
string Process::User() {
     return  LinuxParser::User(_pid);
      }

// TODO: Return the age of this process (in seconds)
long int Process::UpTime() { 
    return  LinuxParser::UpTime(_pid)/sysconf(_SC_CLK_TCK);
  }

// TODO: Overload the "less than" comparison operator for Process objects
// REMOVE: [[maybe_unused]] once you define the function
bool Process::operator<(Process const& a) const { 
   return a.CpuUtilization()<this->CpuUtilization();
      }