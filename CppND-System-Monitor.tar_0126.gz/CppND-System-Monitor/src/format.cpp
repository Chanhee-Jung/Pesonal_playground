#include <string>

#include "format.h"

using std::string;

// TODO: Complete this helper function
// INPUT: Long int measuring seconds
// OUTPUT: HH:MM:SS
// REMOVE: [[maybe_unused]] once you define the function
string time_formating(int time, string str_time);
string Format::ElapsedTime(long seconds){
    
    int sec= (int) seconds % 60;
    int min = seconds/ 60;
    int hour = (int) min/60;
    min = min%60;
    string str_sec=std::to_string(sec);
    string str_hour=std::to_string(hour);
    string str_min=std::to_string(min);

  
    str_sec=time_formating(sec,str_sec);
    str_hour=time_formating(hour,str_hour);
    str_min=time_formating(min,str_min);


    return str_hour+":"+str_min+":"+str_sec; 
    
    }
    string time_formating(int time, string str_time)
    {
      if (time < 10)
      {
        str_time="0"+str_time;
      }  
     else
     {

     }
     return str_time;
    }